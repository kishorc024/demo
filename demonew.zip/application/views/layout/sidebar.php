<div class="sidebar" id="sidebar">
            <div class="sidebar-inner slimscroll">
                <div id="sidebar-menu" class="sidebar-menu">
                    <ul>
                        <li class="menu-title">Main</li>
                        <li class="active">
                            <a href="<?php echo base_url();?>"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
                        </li>
						<li>
                            <a href="<?php echo base_url('students');?>"><i class="fa fa-user-md"></i> <span>Students</span></a>
                        </li>
                        <li>
                            <a href="<?php echo base_url('employees');?>"><i class="fa fa-wheelchair"></i> <span>Employees</span></a>
						</li>
						<li>
                            <a href="<?php echo base_url('random');?>"><i class="fa fa-wheelchair"></i> <span>Random NUmber</span></a>
                        </li>
                        
                    </ul>
                </div>
            </div>
        </div>
