<script src="<?php echo base_url();?>assets/js/jquery-3.2.1.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/jquery.slimscroll.js"></script>
    <script src="<?php echo base_url();?>assets/js/Chart.bundle.js"></script>
    <script src="<?php echo base_url();?>assets/js/chart.js"></script>
    <script src="<?php echo base_url();?>assets/js/app.js"></script>

</body>


<!-- Mirrored from dreamguys.co.in/preclinic/template/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 21 Mar 2019 05:10:56 GMT -->
</html>
